let homeStoreEl =document.getElementById("home-score")
let homeStoreEll =document.getElementById("home-scoree")
let homeScore = 0

function increaseHomeScoreOne(){
    homeScore += 1
    homeStoreEl.textContent = homeScore
}
function increaseHomeScoretwo(){
    homeScore += 2
    homeStoreEl.textContent = homeScore
}
function increaseHomeScorethree(){
    homeScore += 3
    homeStoreEl.textContent = homeScore
}
let homeScoree = 0
function increaseHomeScoreOnee(){
    homeScoree += 1
    homeStoreEll.textContent = homeScoree
}
function increaseHomeScoretwoo(){
    homeScoree += 2
    homeStoreEll.textContent = homeScoree
}
function increaseHomeScorethreee(){
    homeScoree += 3
    homeStoreEll.textContent = homeScoree
}


